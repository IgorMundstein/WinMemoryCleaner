Visual Studio 2022 and newer do not support targeting .NET Framework 4.0. To compile and run the app, follow these steps as a workaround.

1. Extract the files to the C:\
2. It must replace files in the directory: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0
3. Open Visual Studio, and you should now see .NET Framework 4.0 as an available target. You will be able to compile and run the app